import sys, time, os

message = 'Life happens fast, and in an instant disaster could strike \n\
When the choices you make mean the difference between life and death \n\
What would you do to put yourself to the test and see if you have what it takes to stay alive? \n\
Would you DO or DIE \n'


def typewriter(message):
    for char in message:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(0.037)


os.system("cls")  # clear
typewriter(message)

print("-----------------------------------LETS START--------------------------------------")

time.sleep(1)


def new_game():
    score = 0
    print("Situation-1 :")
    ans1 = input(
        "You are doing your daily job in your office when you suddenly feel something shaking, A massive 8.0 earthquake, A tall 8 storey building"
        "is brutally rattled, \n"
        "The walls are collapsing, The buildings in front of your eyes are falling down ....\n PLACE YOURSELF IN THIS POSITION \n"
        "What Would You Do?\n"
        "A. Stay put and take cover  \n"
        "B. Take shelter in the doorway \n"
        "C. Run for the closest exit \n Answer: ")
    ans1 = ans1.upper()
    if ans1 == "A":
        score += 1
        message = 'YOU ARE RIGHT!! \n\
You stay under a table which you were working on, the table saves you from the falling debris and you are alive, CONGRATS, you did not DIE--'
        for char in message:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans1 == "B":
        message1 = "INCORRECT \n\
The door way is the riskiest place to take shelter in, the doorway shuts and you get stuck in debris  breathing your LAST BREATHS \n"
        for char in message1:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans1 == "C":
        message2 = "INCORRECT \n\
You lose your balance while running and debris falls on you, you have no way to escape now and you are breathing your 'LAST BREATHS' \n"

        for char in message2:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans1.upper() != "A":
        print("-----")
        print("the right answer is A")
    print("-----")

    ans1w1 = (input("CONTINUE?(YES/NO)"))
    ans1w1 = ans1w1.upper()
    if ans1w1 == "NO":
        message3 = "You Quit, you didn't make the cut \n"
        for char in message3:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.035)
            print("Your Score : ", score)
        quit()

    else:
        message4 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message4:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)

    time.sleep(1)

    print("Situation-2 :")
    ans2 = input(
        "You reach down for a ripened tomato, A 4 foot Rattle Snake accelerates towards ur hand at a speed of 220 miles/hour, \n"
        "As fast as an arrow shot by a bow, The one inch fangs pierce your knuckles and deliver a deadly dose of hemotoxic venom..\n"
        "What Would You Do? \n \n"
        "A. Rush to make a tourniquet (tie your hand tightly with a cloth)\n"
        "B. Carefully wash the wound with soap and water \n"
        "C. Cut the wound and suck out the poison \n Answer: ")
    ans2 = ans2.upper()
    if ans2 == "B":
        score += 1
        message5 = "YOU ARE RIGHT !! \n\
Washing the wound avoids any further infection, you have enough time to make it to the hospital, CONGRATS, you did not DIE \n"
        for char in message5:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans2 == "A":
        message6 = "It massively increases the chance that you will need the limb amputated, worst case situation, you could lose your life \n"
        for char in message6:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans2 == "C":
        message7 = "INCORRECT \n\
Sucking doesnt remove any of the venom, you reach late to the hospital, leading to your death \n"
        for char in message7:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")

    if ans2.upper() != "B":
        print("-----")
        print("the right answer is B")
    print("-----")

    ans1w2 = (input("CONTINUE?(YES/NO)"))
    ans1w2 = ans1w2.upper()
    if ans1w2 == "NO":
        message8 = "You Quit, you didn't make the cut \n"
        for char in message8:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message19 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message19:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)

    time.sleep(1)

    print("Situation-3 :")
    ans3 = input("You are driving your car at 100km/h , You want to stop your car to fill in some gas \n"
                 "But then you realise your brakes aren't working...\n What Would You Do? \n \n"
                 "A. Jam the car into Neutral \n"
                 "B. Use your emergency brakes \n"
                 "C. Turn of ur engine \n Answer: ")
    ans3 = ans3.upper()
    if ans3 == "A":
        score += 1
        message9 = "YOU ARE RIGHT!! \n\
Neutral would stop the car from accelerating and you would keep power brakes and steering allowing you to decelerate and come to a \n\
controlled stop \n"
        for char in message9:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans3 == "B":
        message10 = "INCORRECT \n\
Emergency break on the shoulder is asking for trouble at high speed, More than likely it wouldn't work at all because of the speed \n\
If it did, the car would brake out of control possibly sending the car rolling. \n"
        for char in message10:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans3 == "C":
        message11 = "INCORRECT \n\
Turning the engine off would also decelerate the care but it would be much more difficult to control without power steering and brakes,\n\
hence you lose control and lose your life \n"
        for char in message11:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans3.upper() != "A":
        print("-----")
        print("the right answer is A")
    print("-----")

    ans1w3 = (input("CONTINUE?(YES/NO)"))
    ans1w3 = ans1w3.upper()
    if ans1w3 == "NO":
        message12 = "You Quit, you didn't make the cut \n"
        for char in message12:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message18 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message18:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)

    time.sleep(1)

    print("Situation-4 :")
    ans4 = input("You are riding cycle through the road, when suddenly your path turns out to be dangerous \n"
                 "It's a huge pack of dogs, if you don't act fast you maybe viciously mauled by them..\n What Would You Do? \n \n"
                 "A. Ride Away \n"
                 "B. Drop and Submit \n"
                 "C. Be Aggressive \n Answer: ")
    ans4 = ans4.upper()
    if ans4 == "C":
        score += 1
        message13 = "YOU ARE RIGHT!! \n\
The dogs consider you as a threat and hence leave you alone, CONGRATS, you survived \n"
        for char in message13:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans4 == "A":
        message14 = "INCORRECT \n\
Dogs are known to run at fast speeds, you are going to get outrun by them and taken down, RIP \n"
        for char in message14:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans4 == "B":
        message15 = "INCORRECT \n\
The dogs are going to attack you horribly and you are going to be scarred for life or worse lose your life \n"
        for char in message15:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans4.upper() != "C":
        print("-----")
        print("the right answer is C")
    print("-----")

    ans1w4 = (input("CONTINUE?(YES/NO)"))
    ans1w4 = ans1w4.upper()
    if ans1w4 == "NO":
        message16 = "You Quit, you didn't make the cut \n"
        for char in message16:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message17 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message17:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    time.sleep(1)

    print("Situation-5 :")
    ans5 = input(
        "You are enjoying a nice night of partying with your friends, you decide to have a challenge on who eats 3 cupcakes the fastest \n"
        "You then see your friend choking after swallowing 3 cupcakes, unable to breathe..\n What Would You Do? \n \n"
        "A. Use mouth-mouth CPR \n"
        "B. Begin abdominal thrusts \n"
        "C. Hit him/her on the back \n Answer: ")
    ans5 = ans5.upper()
    if ans5 == "B":
        score += 1
        message20 = "YOU ARE RIGHT!! \n\
You performing abdominal thrusts on your friend leads to him/her regurgitating the cupcakes and hence saving in life, Well Done \n"
        for char in message20:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans5 == "A":
        message21 = "INCORRECT \n\
You performing CPR is not going to work since the wind pipe is completely blocked off leading to your friend's death \n"
        for char in message21:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans5 == "C":
        message22 = "INCORRECT \n\
Hitting him/her on the back does not bring any change in the current situation and your friend dies a painful death \n"
        for char in message22:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans5.upper() != "B":
        print("-----")
        print("the right answer is B")
    print("-----")

    ans1w5 = (input("CONTINUE?(YES/NO)"))
    ans1w5 = ans1w5.upper()
    if ans1w5 == "NO":
        message23 = "You Quit, you didn't make the cut \n"
        for char in message23:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message24 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message24:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    time.sleep(1)

    print("Situation-6 :")
    ans6 = input("You are in a small boat which goes out of control and leads towards a giant ship \n"
                 " What Would You Do? \n \n"
                 "A. Move to the back of the boat  \n"
                 "B. Bail out and swim for it \n"
                 "C. Start the engine \n Answer: ")
    ans6 = ans6.upper()
    if ans6 == "B":
        score += 1
        message25 = "YOU ARE RIGHT!! \n\
You bailing out of the ship and swimming in the flow of the water current until you find a edge grip can save your life , Good job. \n"
        for char in message25:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans6 == "A":
        message26 = "INCORRECT \n\
If everyone moves towards the back of the boat,due to all the weight the ship with topple over you and you would eventually die. \n"
        for char in message26:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans6 == "C":
        message27 = "INCORRECT \n\
Starting the engine would accelerate the boat towards the ship, with a lot of load on you , you would die. \n"
        for char in message27:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans6.upper() != "B":
        print("-----")
        print("the right answer is B")
    print("-----")

    ans1w6 = (input("CONTINUE?(YES/NO)"))
    ans1w6 = ans1w6.upper()
    if ans1w6 == "NO":
        message28 = "You Quit, you didn't make the cut \n"
        for char in message28:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message29 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message29:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)

    time.sleep(1)

    print("Situation-7 :")
    ans7 = input(
        "You are driving your car in a busy city, in the spur of the moment water gushes all over the roads. It is a massive flood  \n"
        "\n What Would You Do? \n \n"
        "A.Steer your car like a boat \n"
        "B.Abandon your car  \n"
        "C.Climb on the roof of your car \n Answer: ")
    ans7 = ans7.upper()
    if ans7 == "B":
        score += 1
        message30 = "YOU WERE RIGHT!! \n\
Abandoning the car and reaching to a high level building is the right thing to-do, you chose the best option! \n"
        for char in message30:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans7 == "A":
        message31 = "INCORRECT \n\
A car's engine isn't similar to a boat's ,so the car would eventually sink and so will your life \n"
        for char in message31:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans7 == "C":
        message32 = "INCORRECT \n\
All the vehicles are colliding against themselves and the buildings ,you'll loose grip on top of your car and get crushed \n\
leading to your tragic death \n"
        for char in message32:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans7.upper() != "B":
        print("-----")
        print("the right answer is B")
    print("-----")

    ans1w7 = (input("CONTINUE?(YES/NO)"))
    ans1w7 = ans1w7.upper()
    if ans1w7 == "NO":
        message33 = "You Quit, you didn't make the cut \n"
        for char in message33:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message34 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message34:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    time.sleep(1)

    print("Situation-8 :")
    ans8 = input("You are in a zoo and you see a wild bear trying to grab a girl from the other side of the cage ,\n"
                 " few people along with you are trying to save that girl. You need to act fast \n What Would You Do? \n \n"
                 "A. Pry open its mouth  \n"
                 "B. Beat branches against ground \n"
                 "C. Smack the bear's sensitive face \n Answer: ")
    ans8 = ans8.upper()
    if ans8 == "B":
        score += 1
        message35 = "YOU WERE RIGHT!! \n\
Beating branches against the ground symbolises danger to the bear ,it tries to defend itself and run away ,letting go of the girl.\n\
GREAT, you saved the girl \n"
        for char in message35:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans8 == "A":
        message36 = "INCORRECT \n\
The teeth of the bear are very strong, trying to open its month is impossible, the girl would die \n"
        for char in message36:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans8 == "C":
        message37 = "INCORRECT \n\
Due to the bear's behavioural inertia, it will continue doing what its doing and it makes no difference to the bear, the girl would die \n"
        for char in message37:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans8.upper() != "B":
        print("-----")
        print("the right answer is B")
    print("-----")

    ans1w8 = (input("CONTINUE?(YES/NO)"))
    ans1w8 = ans1w8.upper()
    if ans1w8 == "NO":
        message38 = "You Quit, you didn't make the cut \n"
        for char in message38:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
        print("Your Score : ", score)
        quit()
    else:
        message39 = "-------------------Here comes your next situation---------------------------- \n"
        for char in message39:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    time.sleep(1)

    print("Situation-9 :")
    ans9 = input(
        "You are skiing all alone,your action packed thrill ride turns into a sheer terror as you're stuck in a tree well \n"
        " before the rescuers arrive, how would you keep yourself alive......\n What Would You Do? \n \n"
        "A. Twist your legs to clear an opening  \n"
        "B. Pull yourself closer to the tree  \n"
        "C. Use your hands to cover your mouth \n Answer: ")
    ans9 = ans9.upper()
    if ans9 == "C":
        score += 1
        message40 = "YOU WERE RIGHT!! \n\
Covering your mouth will prevent the unsolidated snow from suffocating you,do this until the rescue teem arrive and you'll be SAVED! \n "
        for char in message40:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans9 == "A":
        message41 = "INCORRECT \n\
Twisting your legs will lead to branches and snow on the trees fall directly on you and eventually blocking the oxygen supply,\n\
you will die soon \n"
        for char in message41:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    elif ans9 == "B":
        message42 = "INCORRECT \n\
Any disturbance to the tree will lead to snow falling on you , this added snow would pack around you ,blocking oxygen supply,\n\
you will die to soon \n"
        for char in message42:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(0.025)
    else:
        print("Wrong Input")
    if ans9.upper() != "C":
        print("-----")
        print("the right answer is C")
    print("-----")

    print("Your Score : ", score , "/9")


def play_again():
    response = input("Do you want to play again? (YES or NO): ")
    response = response.upper()

    if response == "YES":
        return True

    else:
        return False


time.sleep(2)
new_game()

while play_again():
    new_game()

message43 = "Hope you guys have learnt some life-saving lessons \n"
for char in message43:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.025)

message44 = "Have a nice day :) \n"
for char in message44:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(0.025)

